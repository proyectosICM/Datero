const express = require("express");
const router = express.Router();
const axios = require("axios");
const colors = require("colors");
const { routes } = require("..");
require("dotenv").config();

import EmqxAuthRule from "../models/emqx_auth.js";

const auth = {
  auth: {
    username: "admin",
    password: process.env.EMQX_DEFAULT_APPLICATION_SECRET,
  },
};

global.saverResource = null;
global.alarmResource = null;

/*
 ______  __    __  ______  __  __       ______  ______  ______  ______  __  __  ______  ______  ______  ______    
/\  ___\/\ "-./  \/\  __ \/\_\_\_\     /\  == \/\  ___\/\  ___\/\  __ \/\ \/\ \/\  == \/\  ___\/\  ___\/\  ___\   
\ \  __\\ \ \-./\ \ \ \/\_\/_/\_\/_    \ \  __<\ \  __\\ \___  \ \ \/\ \ \ \_\ \ \  __<\ \ \___\ \  __\\ \___  \  
 \ \_____\ \_\ \ \_\ \___\_\/\_\/\_\    \ \_\ \_\ \_____\/\_____\ \_____\ \_____\ \_\ \_\ \_____\ \_____\/\_____\ 
  \/_____/\/_/  \/_/\/___/_/\/_/\/_/     \/_/ /_/\/_____/\/_____/\/_____/\/_____/\/_/ /_/\/_____/\/_____/\/_____/ 
                                                                                                                  
*/

async function listResources() {
  try {
    const url =
      "http://" + process.env.EMQX_NODE_HOST + ":8085/api/v4/resources/";

    const res = await axios.get(url, auth);

    const size = res.data.data.length;

    if (size == 0) {
      console.log("***** Creating emqx webhook resources *****".green);

      createResources();
    } else if (size == 2) {
      res.data.data.forEach((resource) => {
        if (resource.description == "alarm-webhook") {
          global.alarmResource = resource;

          console.log("▼ ▼ ▼ ALARM RESOURCE FOUND ▼ ▼ ▼ ".bgBlack.white);
          console.log(global.alarmResource);
          console.log("▲ ▲ ▲ ALARM RESOURCE FOUND ▲ ▲ ▲ ".bgBlack.white);
          console.log("\n");
          console.log("\n");
        }

        if (resource.description == "saver-webhook") {
          global.saverResource = resource;

          console.log("▼ ▼ ▼ SAVER RESOURCE FOUND ▼ ▼ ▼ ".bgBlack.white);
          console.log(global.saverResource);
          console.log("▲ ▲ ▲ SAVER RESOURCE FOUND ▲ ▲ ▲ ".bgBlack.white);
          console.log("\n");
          console.log("\n");
        }
      });
    } else {
      function printWarning() {
        console.log(
          "DELETE ALL WEBHOOK EMQX RESOURCES AND RESTART NODE - youremqxdomain:8085/#/resources"
            .red
        );
        setTimeout(() => {
          printWarning();
        }, 1000);
      }

      printWarning();
    }
  } catch (error) {
    console.log(error);
  }
}
//create resources
async function createResources() {
  try {
    const url =
      "http://" + process.env.EMQX_NODE_HOST + ":8085/api/v4/resources";

    const data1 = {
      type: "web_hook",
      config: {
        url: "http://" + process.env.EMQX_NODE_HOST + ":3001/api/saver-webhook",
        method: "POST",
      },
      description: "saver-webhook",
    };

    const data2 = {
      type: "web_hook",
      config: {
        url: "http://" + process.env.EMQX_NODE_HOST + ":3001/api/alarm-webhook",
        method: "POST",
      },
      description: "alarm-webhook",
    };

    const res1 = await axios.post(url, data1, auth);

    if (res1.status === 200) {
      console.log("Saver resource created!".green);
    }

    const res2 = await axios.post(url, data2, auth);

    if (res2.status === 200) {
      console.log("Alarm resource created!".green);
    }

    setTimeout(() => {
      console.log("***** Emqx WH resources created! :) *****".green);
      listResources();
    }, 1000);
  } catch (error) {
    console.log("Error creating resources");
    console.log(error);
  }
}

//check if superuser exist if not we create one
global.check_mqtt_superuser = async function checkMqttSuperUser() {
  try {
    const superusers = await EmqxAuthRule.find({ type: "superuser" });

    if (superusers.length > 0) {
      return;
    } else if (superusers.length == 0) {
      await EmqxAuthRule.create({
        publish: ["#"],
        subscribe: ["#"],
        userId: "aaaaaaaaaaa",
        username: "superuser",
        password: "superuser",
        type: "superuser",
        time: Date.now(),
        updatedTime: Date.now(),
      });

      console.log("Mqtt super user created");
    }
  } catch (error) {
    console.log("error creating mqtt superuser ");
    console.log(error);
  }
};

setTimeout(() => {
  listResources();
}, 3000);

module.exports = router;
