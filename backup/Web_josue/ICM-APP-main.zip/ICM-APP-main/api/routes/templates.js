const express = require("express");
const router = express.Router();
const { checkAuth } = require("../middlewares/authentication.js");

import Template from "../models/template.js";
import Device from "../models/device.js";
/*
 ______  ______  __    
/\  __ \/\  == \/\ \   
\ \  __ \ \  _-/\ \ \  
 \ \_\ \_\ \_\   \ \_\ 
  \/_/\/_/\/_/    \/_/ 
*/
// Obtener template
router.get("/template", checkAuth, async (req, res) => {
  try {
    const userId = req.userData._id;
    const templates = await Template.find({ userId: userId });

    console.log(userId);
    console.log(templates);

    const response = {
      status: "success",
      data: templates,
    };

    return res.json(response);
  } catch (error) {
    console.log(error);

    const response = {
      status: "error",
      error: error,
    };

    return res.status(500).json(response);
  }
});
// Nuevo template
router.post("/template", checkAuth, async (req, res) => {
  try {
    const userId = req.userData._id;

    let newTemplate = req.body.template;
    newTemplate.userId = userId;
    newTemplate.createdTime = Date.now();

    const template = await Template.create(newTemplate);
    const response = {
      status: "success",
    };
    return res.json(response);
  } catch (error) {
    console.log(error);
    const response = {
      status: "error",
      error: error,
    };
    return res.status(500).json(response);
  }
});
// Borrar template
router.delete("/template", checkAuth, async (req, res) => {
  try {
    const userId = req.userData._id;
    const templateId = req.query.templateId;

    const devices = await Device.find({
      userId: userId,
      templateId: templateId,
    });

    if (devices.length > 0) {
      const response = {
        status: "fail",
        error: "template in use",
      };

      return res.json(response);
    }

    const r = await Template.deleteOne({ userId: userId, _id: templateId });

    const response = {
      status: "success",
    };

    return res.json(response);
  } catch (error) {
    console.log(error);

    const response = {
      status: "error",
      error: error,
    };

    return res.status(500).json(response);
  }
});
module.exports = router;
