const express = require("express");
const mongoose = require("mongoose");
const morgan = require("morgan");
const cors = require("cors");
const colors = require("colors");

require("dotenv").config();
//instances
const app = express();

//express config
app.use(morgan("tiny"));
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(cors());

/*
 ______  __  __  ______  ______  ______    
/\  == \/\ \/\ \/\__  _\/\  __ \/\  ___\   
\ \  __<\ \ \_\ \/_/\ \/\ \  __ \ \___  \  
 \ \_\ \_\ \_____\ \ \_\ \ \_\ \_\/\_____\ 
  \/_/ /_/\/_____/  \/_/  \/_/\/_/\/_____/ 
                                           
*/
app.use("/api", require("./routes/devices.js"));
app.use("/api", require("./routes/users.js"));
app.use("/api", require("./routes/templates.js"));
app.use("/api", require("./routes/webhooks.js"));
app.use("/api", require("./routes/emqxapi.js"));
app.use("/api", require("./routes/alarms.js"));
app.use("/api", require("./routes/dataprovider.js"));

module.exports = app;

//listener
app.listen(process.env.API_PORT, () => {
  console.log(`\nAPI server listen on \n`.green + process.env.API_PORT);
});

//Mongo Connection
// Variables
const mongoUserName = process.env.MONGO_USERNAME;
const mongoPassword = process.env.MONGO_PASSWORD;
const mongoHost = process.env.MONGO_HOST;
const mongoPort = process.env.MONGO_PORT;
const mongoDatabase = process.env.MONGO_DATABASE;

let uri =
  "mongodb://" +
  mongoUserName +
  ":" +
  mongoPassword +
  "@" +
  mongoHost +
  ":" +
  mongoPort +
  "/" +
  mongoDatabase;

const options = {
  useNewUrlParser: true,
  useCreateIndex: true,
  useUnifiedTopology: true,
  useNewUrlParser: true,
  authSource: "admin",
};
// Connection
try {
  mongoose.connect(uri, options).then(
    () => {
      console.log("\n");
      console.log("*******************************".blue);
      console.log("✔ Mongo Successfully Connected!".blue);
      console.log("*******************************".blue);
      console.log("\n");
      global.check_mqtt_superuser();
    },
    (err) => {
      console.log("\n");
      console.log("*******************************".red);
      console.log("    Mongo Connection Failed    ".red);
      console.log("*******************************".red);
      console.log("\n");
      console.log(err);
    }
  );
} catch (error) {
  console.log("ERROR CONNECTING MONGO ");
  console.log(error);
}
