<template>
  <div>
      <h1> Texto sobre ICM </h1>
  </div>
</template>