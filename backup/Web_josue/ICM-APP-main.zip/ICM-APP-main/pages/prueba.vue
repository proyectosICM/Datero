<template>
  <div>
    <h1>Hola</h1>    
  </div>

</template>

<script>
</script>
