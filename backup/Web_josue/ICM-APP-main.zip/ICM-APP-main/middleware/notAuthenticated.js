// Poner en las vistas donde el usuario no tendria que estar autenticado
export default function ({ store, redirect }) {
  store.dispatch("readToken");

  if (store.state.auth) {
    return redirect("/dashboard");
  }
}
