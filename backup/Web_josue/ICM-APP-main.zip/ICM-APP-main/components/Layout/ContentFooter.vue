<template>
  <footer class="footer">
    <div class="container-fluid">
      <ul class="nav">
        <li class="nav-item">
          <a
            href="https://pe.linkedin.com/in/icm-s-a-c-14531a32?original_referer=https%3A%2F%2Fwww.google.com%2F"
            target="_blank"
            rel="noopener"
            class="nav-link"
          >
            ICM SAC
          </a>
        </li>
        <li class="nav-item">
          <a
            href="https://www.ingenieriamecatronica.com/"
            target="_blank"
            rel="noopener"
            class="nav-link"
          >
            Sobre nosotros
          </a>
        </li>

      </ul>
      <div class="copyright">
        &copy; {{ year }}, hecho con amor <i class="tim-icons icon-heart-2"></i> by
        
        <a
          href="https://www.creative-tim.com/?ref=pdf-vuejs"
          target="_blank"
          rel="noopener"
          >Josue y Angie</a
        >
        para ICM.
      </div>
    </div>
  </footer>
</template>
<script>
export default {
  data() {
    return {
      year: new Date().getFullYear()
    };
  }
};
</script>
<style></style>
